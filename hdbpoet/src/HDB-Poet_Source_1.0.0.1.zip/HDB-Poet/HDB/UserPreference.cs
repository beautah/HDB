using System;
using System.Data;
using System.IO;

namespace Karl.Tools
{
	/// <summary>
	/// Summary description for UserPreference.
	/// </summary>
	public class UserPreference
	{
		DataTable table=null;
		DataSet dataSet;
		string filename;
		public UserPreference()
		{
		  
			filename = "UserPref.xml";
			FileInfo fi = new FileInfo(filename);
			dataSet = new DataSet();
			if( fi.Exists )
			{
				dataSet.ReadXml(filename,XmlReadMode.ReadSchema);
				table = dataSet.Tables["user"];
			}
			else // Create new Defaults User preference file 
			{
			table = new DataTable("user");
			table.Columns.Add("Name",typeof(String));
			table.Columns.Add("Value",typeof(String));
		
			AddRow("UserName","");
			AddRow("Password","");
			AddRow("ChartWidth","656");
			AddRow("Inputs","");
			AddRow("Filename","edits.txt");
			AddRow("Directory","");
			AddRow("DataSource","hdb"); 
			AddRow("OracleUser","yakhdb");
			AddRow("OracleService","yakhdb");
			AddRow("OracleProvider","MSDAORA"); 
			AddRow("GraphFilename","");
			dataSet.Tables.Add(table);

			Save();
			}
		}

		private void AddRow(string name, string value)
		{
			DataRow row = table.NewRow();
			row["Name"] = name;
			row["Value"] = value;
			table.Rows.Add(row);
		}

		public string Lookup(string name)
		{
		DataRow[] rows;
		string rval = "";
			
		rows = table.Select("Name = '"+name+"'");
			if (rows.Length >0)
			{
				rval = (string)rows[0]["Value"];
				if( name == "Password" && rval != "")
				{
				rval = SymmCrypto.DecryptRijndael(rval,"roter0832v");
				}
			}

				

		return rval;

		}
		public void Change(string name, string newValue)
		{
			DataRow[] rows;
			if( name == "Password" && newValue != "")
			{
			 newValue = SymmCrypto.EncryptRijndael(newValue,"roter0832v");
			}
			
			rows = table.Select("Name = '"+name+"'");
			if (rows.Length >0)
			{
				rows[0]["Value"] = newValue;
			}
			else
			{ // insert row.
				DataRow newRow = table.NewRow();
				newRow["Value"]= newValue;
				newRow["Name"] = name;
				table.Rows.Add(newRow);
			}
				
		}
		public void Save()
		{
		 dataSet.WriteXml(filename,XmlWriteMode.WriteSchema);
		}
	}
}

