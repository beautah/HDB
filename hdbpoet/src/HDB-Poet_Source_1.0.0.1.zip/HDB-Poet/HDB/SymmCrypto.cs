using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;

//http://www.codeproject.com/csharp/Encryption.asp
// By Frank Fang 
namespace HydrometTools
{
	/// <summary>
	/// SymmCrypto is a wrapper of System.Security.Cryptography.SymmetricAlgorithm classes
	/// and simplifies the interface. It supports customized SymmetricAlgorithm as well.
	/// </summary>
	public class SymmCrypto
	{
		/// <remarks>
		/// Supported .Net intrinsic SymmetricAlgorithm classes.
		/// </remarks>
		public enum SymmProvEnum : int
		{
			DES, RC2, Rijndael
		}

		private SymmetricAlgorithm mobjCryptoService;

		/// <remarks>
		/// Constructor for using an intrinsic .Net SymmetricAlgorithm class.
		/// </remarks>
		public SymmCrypto(SymmProvEnum NetSelected)
		{
			switch (NetSelected)
			{
				case SymmProvEnum.DES:
					mobjCryptoService = new DESCryptoServiceProvider();
					break;
				case SymmProvEnum.RC2:
					mobjCryptoService = new RC2CryptoServiceProvider();
					break;
				case SymmProvEnum.Rijndael:
					mobjCryptoService = new RijndaelManaged();
					break;
			}
		}

		/// <remarks>
		/// Constructor for using a customized SymmetricAlgorithm class.
		/// </remarks>
		public SymmCrypto(SymmetricAlgorithm ServiceProvider)
		{
			mobjCryptoService = ServiceProvider;
		}

		/// <remarks>
		/// Depending on the legal key size limitations of a specific CryptoService provider
		/// and length of the private key provided, padding the secret key with space character
		/// to meet the legal size of the algorithm.
		/// </remarks>
		private byte[] GetLegalKey(string Key)
		{
			string sTemp = Key;
			if (mobjCryptoService.LegalKeySizes.Length > 0)
			{
				int moreSize = mobjCryptoService.LegalKeySizes[0].MinSize;
				// key sizes are in bits
				if (sTemp.Length * 8 > mobjCryptoService.LegalKeySizes[0].MaxSize)
					// get the left of the key up to the max size allowed
					sTemp = sTemp.Substring(0, mobjCryptoService.LegalKeySizes[0].MaxSize / 8);
				else if (sTemp.Length * 8 < moreSize)
					if (mobjCryptoService.LegalKeySizes[0].SkipSize == 0)
						// simply pad the key with spaces up to the min size allowed
						sTemp = sTemp.PadRight(moreSize / 8, ' ');
					else
					{
						while (sTemp.Length * 8 > moreSize)
							moreSize += mobjCryptoService.LegalKeySizes[0].SkipSize;

						sTemp = sTemp.PadRight(moreSize / 8, ' ');
					}
			}

			// convert the secret key to byte array
			return ASCIIEncoding.ASCII.GetBytes(sTemp);
		}

		public string Encrypting(string Source, string Key)
		{
			byte[] bytIn = System.Text.ASCIIEncoding.ASCII.GetBytes(System.Web.HttpUtility.UrlEncode(Source));

			// create a MemoryStream so that the process can be done without I/O files
			System.IO.MemoryStream ms = new System.IO.MemoryStream();

			byte[] bytKey = GetLegalKey(Key);

			// set the private key
			mobjCryptoService.Key = bytKey;
			mobjCryptoService.IV = bytKey;

			// create an Encryptor from the Provider Service instance
			ICryptoTransform encrypto = mobjCryptoService.CreateEncryptor();

			// create Crypto Stream that transforms a stream using the encryption
			CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Write);

			// write out encrypted content into MemoryStream
			cs.Write(bytIn, 0, bytIn.Length);
			cs.FlushFinalBlock();

			// get the output and trim the '\0' bytes
			byte[] bytOut = ms.GetBuffer();
			int i = 0;
			for (i = 0; i < bytOut.Length; i++)
				if (bytOut[i] == 0)
					break;

			// convert into Base64 so that the result can be used in xml
			return System.Convert.ToBase64String(bytOut, 0, i);
		}

		public string Decrypting(string Source, string Key)
		{
			// convert from Base64 to binary
			byte[] bytIn = System.Convert.FromBase64String(Source);
			// create a MemoryStream with the input
			System.IO.MemoryStream ms = new System.IO.MemoryStream(bytIn, 0, bytIn.Length);

			byte[] bytKey = GetLegalKey(Key);

			// set the private key
			mobjCryptoService.Key = bytKey;
			mobjCryptoService.IV = bytKey;

			// create a Decryptor from the Provider Service instance
			ICryptoTransform encrypto = mobjCryptoService.CreateDecryptor();

			// create Crypto Stream that transforms a stream using the decryption
			CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Read);
			
			// read out the result from the Crypto Stream
			System.IO.StreamReader sr = new System.IO.StreamReader( cs );
			string sEncoded = sr.ReadToEnd();
			return System.Web.HttpUtility.UrlDecode(sEncoded);
		}

		public static string EncryptDES(string Source, string Key)
		{
			SymmCrypto objCrypto = new SymmCrypto(SymmCrypto.SymmProvEnum.DES);
			return objCrypto.Encrypting(Source, Key);
		}

		public static string DecryptDES(string Source, string Key)
		{
			SymmCrypto objCrypto = new SymmCrypto(SymmCrypto.SymmProvEnum.DES);
			return objCrypto.Decrypting(Source, Key);
		}

		public static string EncryptRC2(string Source, string Key)
		{
			SymmCrypto objCrypto = new SymmCrypto(SymmCrypto.SymmProvEnum.RC2);
			return objCrypto.Encrypting(Source, Key);
		}

		public string DecryptRC2(string Source, string Key)
		{
			SymmCrypto objCrypto = new SymmCrypto(SymmCrypto.SymmProvEnum.RC2);
			return objCrypto.Decrypting(Source, Key);
		}

		public static string EncryptRijndael(string Source, string Key)
		{
			SymmCrypto objCrypto = new SymmCrypto(SymmCrypto.SymmProvEnum.Rijndael);
			return objCrypto.Encrypting(Source, Key);
		}

		public static string DecryptRijndael(string Source, string Key)
		{
			SymmCrypto objCrypto = new SymmCrypto(SymmCrypto.SymmProvEnum.Rijndael);
			return objCrypto.Decrypting(Source, Key);
		}

	}
}
