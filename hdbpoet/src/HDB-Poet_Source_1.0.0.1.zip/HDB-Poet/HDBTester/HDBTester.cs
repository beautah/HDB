using System;
using Karl.Tools;
using System.Data;
using System.Data.OleDb;
using HDBBrowser;
namespace HDBTester
{
	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
		Oracle oracle = new Oracle();
		HDB.Oracle = oracle;
		
		DataTable tbl = oracle.Table("tmp","select count(*) from hdb_unit");
		if( tbl.Rows.Count>0 && tbl.Columns.Count>0)
		  Console.WriteLine(" there are "+tbl.Rows[0][0]+" rows in hdb_unit");
		 else
      Console.WriteLine("Error reading hdb_unit");



      /*
       * 
       * GUNC	  hm_site_code
       * DPC	 hp_pcode
       * A       hm_filetype
       * 692    site_datatype_id
       */

      int rval = HDB.modify_r_base(692,"day", new DateTime(2003,4,19), 
        DateTime.MinValue, 
        -12,null,"Z","Y");
      Console.WriteLine(rval);
      Console.WriteLine();
      //

      /*rval = HDB.modify_r_base_raw(692,"day", new DateTime(2003,4,19), 
               new DateTime(2003,4,20), 
               -13,null,"Z",7,5,8,5,1,"Y");
               Console.WriteLine(rval);
               Console.WriteLine();
               */
		//HDB.check_valid_role_name("abc");
		
		}
    /*
     * int rval = HDB.modify_r_base_raw(205,"day", new DateTime(1994,4,23), 
               new DateTime(1994,4,24), 
               15,"Y","Z",7,5,8,15,1,"N");
               Console.WriteLine(rval);
               Console.WriteLine();
		//
     * */
	}
}
